star="*"
ls $1$star
