echo "Enter first num of Fibonacci Series"
read x;
echo "Enter second num of the Fibonacci Series"
read y;

echo "Enter the length of the Fibonacci series till you want to display:"
read n;
m=$(($n +1))
cnt=1;
while test $cnt -ne $m
do
c=$((x+y))
echo $c
x=$((y+0))
y=$((c+0))
cnt=`expr $cnt + 1`
done
