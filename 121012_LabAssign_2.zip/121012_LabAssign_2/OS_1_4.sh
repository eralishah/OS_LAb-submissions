echo Enter the first number
read m
echo Enter the second number
read n 
if [ $m -gt $n ]
then
	echo "$m is greater than $n"

elif [ $m -eq $n ]
then
	echo "both m and n are equal"
else 
	echo "$m is greater than $n"
fi

