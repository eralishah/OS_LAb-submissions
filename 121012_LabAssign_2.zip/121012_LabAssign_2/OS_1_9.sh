while [ 1 ]
do
	echo enter the capital of Gujarat
	read a
	if [ $a = "Gandhinagar" ]
		then 
			echo Congrates
			break
		else
			continue
fi
done 
	


