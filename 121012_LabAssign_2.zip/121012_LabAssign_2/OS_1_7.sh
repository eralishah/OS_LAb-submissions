echo "Enter January month initials:";
read month
	case $month in 
		jan ) 
		echo "january";;
	
		janu ) 
		echo "january";;

		janua ) 
		echo "january";;

		january ) 	
		echo "january";;

		*)   echo "enter valid month";;  

esac


