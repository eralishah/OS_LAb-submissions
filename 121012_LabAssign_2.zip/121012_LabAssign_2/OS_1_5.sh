
ch=1
while [ $ch -ne 0 ]
do
echo Enter a number:
read n1

	if [ $n1 -gt 50 ]
	then 
		echo 'Enter number less than 50'
		exit 1 
	else
		echo "The output is `expr $n1 \* $n1`"
		
	fi
echo "Do You want to continue?(yes=1/n=0)" 
read ch
done
