

case $2 in

+)add= `expr $1 + $3`;
echo add: $add;;

\*)mul= `expr $1 \* $3`;
echo mul: $mul;;

-)sub= `expr $1 - $3`;
echo sub: $sub;;

%)mod= `expr $1 % $3`;
echo mod: $mod;;

*) echo "Invalid";;

esac
