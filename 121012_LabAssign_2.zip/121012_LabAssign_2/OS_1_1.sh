m=50;
n=10;

echo m: $m;
echo n: $n;

sum= `expr $m + $n`
echo sum: $sum;

mul= `expr $m + $n`
echo mul: $mul;

div= `expr $m / $n`
echo div: $div;

sub= `expr $m - $n`
echo sub: $sub;

mod= `expr $m % $n`
echo mod: $mod;

