echo "Enter Command"
read com
exec $com
