
echo Enter number 1
read m
echo enter number 2
read n
 
echo 'Enter operation to perform:'
echo 1-Add
echo 2-Subtract
echo 3-Multipliply
echo 4-division
echo 5-Modulo
read p
if [ $p = 1 ]
then 
echo `expr $n1 + $n2`
fi
if [ $p = 2 ]
then 
echo `expr $n1 - $n2`
fi
if [ $p = 3 ]
then 
echo `expr $n1 \* $n2`
fi
if [ $p = 4 ]
then 
if [ $n2 != 0 ]
then
echo `expr $n1 \/ $n2`
fi
fi
if [ $p = 5 ]
then 
echo ` expr $n1 \% $n2`
fi



