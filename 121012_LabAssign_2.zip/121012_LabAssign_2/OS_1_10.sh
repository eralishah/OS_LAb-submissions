cartoon=("tom" "jerry" "tweety" "pokemon" "popeye" "noddy");
echo -n "enter the cartoon you want to search  "
read string
search=`echo ${cartoon[*]} | grep "$string"`

if [ "${search}" != "" ]; then
  echo -n The list contains : $string 
else
  echo -n $string is not present. Try another
fi
